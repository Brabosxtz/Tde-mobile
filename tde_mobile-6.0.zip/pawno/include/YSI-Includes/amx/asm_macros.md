amx_assembly asm_macros
==========================================
AMX Assembly Library: `@emit` macros.
------------------------------------------

