# Quick Start

```pawn
#include <YSI_Server\y_serverdata>

public OnScriptInit()
{
	// Called at the start, in both gamemodes and filterscripts.
}
```

