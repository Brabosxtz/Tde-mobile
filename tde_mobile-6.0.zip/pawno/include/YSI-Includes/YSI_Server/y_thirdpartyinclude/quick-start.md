# Quick Start

```pawn
#include <YSI_Server\y_thirdpartyinclude>
// You can now use md-sort, indirection, amx_assembly, and code-parse.
```
