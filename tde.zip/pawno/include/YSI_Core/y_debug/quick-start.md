Debug levels:

`P:1` - Public (callback/timer) called.
`P:2` - API function (`stock`/none) called.
`P:3` - Internal function (`static`) called.
`P:4` - **y_utils** function called.
`P:5` - Extra debug lines within a function (outside loops).
`P:6` - Extra debug lines within a loop.
`P:7` - **y_amx** and **y_cell** functions called.

